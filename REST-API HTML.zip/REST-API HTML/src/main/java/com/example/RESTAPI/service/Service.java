package com.example.RESTAPI.service;


public class Service {
    public String exampleView(){
        return "Acesse <a href='http://localhost:8080/>localhost:8080</a>" + "para visualizar o conteudo do arquivo resources/static/index.html.";
    }

}
